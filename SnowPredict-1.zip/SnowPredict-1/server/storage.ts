import { type ContactInput, type PredictionInput, type PredictionResult, type WeatherData } from "@shared/schema";

export interface IStorage {
  savePrediction(input: PredictionInput, result: PredictionResult): Promise<void>;
  saveContact(contact: ContactInput): Promise<void>;
  getPredictionHistory(zipCode: string): Promise<PredictionResult[]>;
}

export class MemStorage implements IStorage {
  private predictions: Map<string, PredictionResult[]> = new Map();
  private contacts: ContactInput[] = [];

  async savePrediction(input: PredictionInput, result: PredictionResult): Promise<void> {
    const existing = this.predictions.get(input.zipCode) || [];
    existing.push(result);
    this.predictions.set(input.zipCode, existing);
  }

  async saveContact(contact: ContactInput): Promise<void> {
    this.contacts.push(contact);
  }

  async getPredictionHistory(zipCode: string): Promise<PredictionResult[]> {
    return this.predictions.get(zipCode) || [];
  }
}

export const storage = new MemStorage();
