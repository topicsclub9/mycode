import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { predictionSchema, contactSchema, type PredictionInput, type PredictionResult, type WeatherData } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get weather data from OpenWeatherMap API
  app.post("/api/weather", async (req, res) => {
    try {
      const { zipCode } = req.body;
      
      if (!zipCode) {
        return res.status(400).json({ error: "ZIP code is required" });
      }

      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.WEATHER_API_KEY || "demo_key";
      
      // Get coordinates from ZIP code
      const geoUrl = `http://api.openweathermap.org/geo/1.0/zip?zip=${zipCode}&appid=${apiKey}`;
      const geoResponse = await fetch(geoUrl);
      
      if (!geoResponse.ok) {
        return res.status(400).json({ error: "Invalid ZIP code or weather service unavailable" });
      }
      
      const geoData = await geoResponse.json();
      const { lat, lon } = geoData;
      
      // Get current weather and forecast
      const weatherUrl = `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=imperial`;
      const weatherResponse = await fetch(weatherUrl);
      
      if (!weatherResponse.ok) {
        return res.status(500).json({ error: "Weather data unavailable" });
      }
      
      const weatherData = await weatherResponse.json();
      
      // Process weather data for next 24 hours
      const next24Hours = weatherData.list.slice(0, 8); // 8 3-hour periods = 24 hours
      
      let totalSnowfall = 0;
      let avgTemp = 0;
      let maxWind = 0;
      let hasSnow = false;
      let iceRisk = false;
      
      next24Hours.forEach((period: any) => {
        avgTemp += period.main.temp;
        maxWind = Math.max(maxWind, period.wind.speed);
        
        if (period.snow && period.snow['3h']) {
          totalSnowfall += period.snow['3h'] * 0.393701; // Convert mm to inches
          hasSnow = true;
        }
        
        if (period.main.temp <= 32 && period.weather[0].description.includes('rain')) {
          iceRisk = true;
        }
      });
      
      avgTemp = avgTemp / next24Hours.length;
      
      const processedWeather: WeatherData = {
        temperature: Math.round(avgTemp),
        snowfall: Math.round(totalSnowfall * 10) / 10,
        windSpeed: Math.round(maxWind),
        conditions: hasSnow ? "snow" : next24Hours[0].weather[0].main.toLowerCase(),
        stormTiming: getStormTiming(next24Hours),
        iceRisk
      };
      
      res.json(processedWeather);
      
    } catch (error) {
      console.error("Weather API error:", error);
      res.status(500).json({ error: "Weather service unavailable" });
    }
  });

  // Calculate snow day prediction
  app.post("/api/predict", async (req, res) => {
    try {
      const validatedInput = predictionSchema.parse(req.body);
      
      let weatherData: WeatherData;
      
      if (validatedInput.manualWeather) {
        // Use manual weather data
        const manual = validatedInput.manualWeather;
        weatherData = {
          temperature: manual.temperature,
          snowfall: manual.snowfall,
          windSpeed: manual.windSpeed,
          conditions: manual.snowfall > 0 ? "snow" : "clear",
          stormTiming: manual.stormStartTime,
          iceRisk: manual.freezingRain || manual.iceStorm || manual.blackIce
        };
      } else {
        // Fetch real weather data
        const weatherResponse = await fetch(`http://localhost:${process.env.PORT || 5000}/api/weather`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ zipCode: validatedInput.zipCode })
        });
        
        if (!weatherResponse.ok) {
          return res.status(400).json({ error: "Unable to fetch weather data" });
        }
        
        weatherData = await weatherResponse.json();
      }
      
      // Calculate prediction using algorithm
      const prediction = calculateSnowDayPrediction(validatedInput, weatherData);
      
      // Save prediction
      await storage.savePrediction(validatedInput, prediction);
      
      res.json(prediction);
      
    } catch (error) {
      console.error("Prediction error:", error);
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid input" });
    }
  });

  // Submit contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedContact = contactSchema.parse(req.body);
      await storage.saveContact(validatedContact);
      res.json({ message: "Contact form submitted successfully" });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Invalid input" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function getStormTiming(forecast: any[]): string {
  const snowPeriods = forecast.filter(period => period.snow && period.snow['3h'] > 0);
  if (snowPeriods.length === 0) return "none";
  
  const firstSnowHour = new Date(snowPeriods[0].dt * 1000).getHours();
  
  if (firstSnowHour >= 18 || firstSnowHour < 6) return "overnight";
  if (firstSnowHour >= 6 && firstSnowHour < 10) return "morning-commute";
  return "daytime";
}

function calculateSnowDayPrediction(input: PredictionInput, weather: WeatherData): PredictionResult {
  let score = 0;
  const weatherFactors: string[] = [];
  const schoolFactors: string[] = [];
  const reasoning: string[] = [];
  
  // Weather scoring
  if (weather.snowfall >= 6) {
    score += 40;
    weatherFactors.push(`${weather.snowfall}" snowfall expected`);
    reasoning.push("Heavy snowfall significantly increases closure likelihood");
  } else if (weather.snowfall >= 3) {
    score += 25;
    weatherFactors.push(`${weather.snowfall}" snowfall expected`);
    reasoning.push("Moderate snowfall increases closure chances");
  } else if (weather.snowfall >= 1) {
    score += 10;
    weatherFactors.push(`${weather.snowfall}" snowfall expected`);
  }
  
  // Storm timing
  if (weather.stormTiming === "overnight") {
    score += 20;
    weatherFactors.push("Storm peaks overnight");
    reasoning.push("Overnight storms allow time for road treatment");
  } else if (weather.stormTiming === "morning-commute") {
    score += 35;
    weatherFactors.push("Storm during morning commute");
    reasoning.push("Morning commute timing creates dangerous conditions");
  }
  
  // Temperature effects
  if (weather.temperature <= 20) {
    score += 15;
    weatherFactors.push(`Very cold temperature (${weather.temperature}°F)`);
    reasoning.push("Extreme cold makes snow removal difficult");
  } else if (weather.temperature >= 32) {
    score -= 10;
    weatherFactors.push(`Above freezing (${weather.temperature}°F)`);
    reasoning.push("Above freezing temperatures reduce accumulation");
  }
  
  // Wind effects
  if (weather.windSpeed >= 25) {
    score += 15;
    weatherFactors.push(`High winds (${weather.windSpeed} mph)`);
    reasoning.push("High winds create dangerous driving conditions");
  }
  
  // Ice risk
  if (weather.iceRisk) {
    score += 25;
    weatherFactors.push("Ice conditions expected");
    reasoning.push("Ice significantly increases closure probability");
  }
  
  // School type adjustments
  switch (input.schoolType) {
    case "public-urban":
      score += 5;
      schoolFactors.push("Public urban district (cautious policy)");
      break;
    case "public-rural":
      score += 10;
      schoolFactors.push("Public rural district (limited resources)");
      reasoning.push("Rural districts often close earlier due to bus routes");
      break;
    case "private-prep":
      score -= 10;
      schoolFactors.push("Private school (flexible policy)");
      reasoning.push("Private schools often have more flexibility");
      break;
    case "boarding":
      score -= 20;
      schoolFactors.push("Boarding school (students on campus)");
      reasoning.push("Boarding schools rarely close due to on-campus housing");
      break;
  }
  
  // Snow days used adjustment
  if (input.snowDaysUsed >= 4) {
    score -= 15;
    schoolFactors.push(`${input.snowDaysUsed} snow days already used`);
    reasoning.push("Schools are reluctant to use remaining snow days");
  } else {
    schoolFactors.push(`${input.snowDaysUsed} snow days used this year`);
  }
  
  // Ensure score is within bounds
  const percentage = Math.max(0, Math.min(100, score));
  
  let status: "Low" | "Moderate" | "High" | "Very High";
  if (percentage >= 80) status = "Very High";
  else if (percentage >= 60) status = "High";
  else if (percentage >= 30) status = "Moderate";
  else status = "Low";
  
  return {
    percentage,
    status,
    reasoning,
    weatherFactors,
    schoolFactors,
    lastUpdated: new Date().toLocaleString()
  };
}
