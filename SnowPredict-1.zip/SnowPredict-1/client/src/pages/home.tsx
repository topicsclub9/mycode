import { Snowflake, Users, TrendingUp, Clock, Grid3x3 } from "lucide-react";
import { useState } from "react";
import CalculatorForm from "@/components/calculator-form";
import PredictionResults from "@/components/prediction-results";
import HowItWorks from "@/components/how-it-works";
import ContactForm from "@/components/contact-form";
import { Button } from "@/components/ui/button";
import { type PredictionResult } from "@shared/schema";

export default function Home() {
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setShowMobileMenu(false);
  };

  return (
    <div className="min-h-screen winter-gradient">
      {/* Header */}
      <header className="bg-blue-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <Snowflake className="text-white text-3xl" />
              <h1 className="text-white text-2xl font-bold">Snow Day Calculator</h1>
            </div>
            <nav className="hidden md:flex space-x-8">
              <button 
                onClick={() => scrollToSection('calculator')}
                className="text-white hover:text-blue-100 transition-colors"
              >
                Calculator
              </button>
              <button 
                onClick={() => scrollToSection('how-it-works')}
                className="text-white hover:text-blue-100 transition-colors"
              >
                How It Works
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="text-white hover:text-blue-100 transition-colors"
              >
                Contact
              </button>
            </nav>
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden text-white"
              onClick={() => setShowMobileMenu(!showMobileMenu)}
            >
              <Grid3x3 className="h-6 w-6" />
            </Button>
          </div>
          {showMobileMenu && (
            <div className="md:hidden py-4 border-t border-blue-500">
              <div className="flex flex-col space-y-4">
                <button 
                  onClick={() => scrollToSection('calculator')}
                  className="text-white hover:text-blue-100 transition-colors text-left"
                >
                  Calculator
                </button>
                <button 
                  onClick={() => scrollToSection('how-it-works')}
                  className="text-white hover:text-blue-100 transition-colors text-left"
                >
                  How It Works
                </button>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="text-white hover:text-blue-100 transition-colors text-left"
                >
                  Contact
                </button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-cover bg-center opacity-20" 
             style={{backgroundImage: "url('https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"}} />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-5xl font-bold text-gray-800 mb-6">Will You Have a Snow Day Tomorrow?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Get wickedly accurate snow day predictions using real-time weather data, historical school closure patterns, and advanced algorithms trusted by millions.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="bg-white rounded-lg shadow-md p-4 flex items-center space-x-3">
              <Users className="text-blue-600 text-2xl" />
              <span className="text-gray-800 font-semibold">5M+ Users Annually</span>
            </div>
            <div className="bg-white rounded-lg shadow-md p-4 flex items-center space-x-3">
              <TrendingUp className="text-green-500 text-2xl" />
              <span className="text-gray-800 font-semibold">95% Accuracy Rate</span>
            </div>
            <div className="bg-white rounded-lg shadow-md p-4 flex items-center space-x-3">
              <Clock className="text-yellow-500 text-2xl" />
              <span className="text-gray-800 font-semibold">Real-time Updates</span>
            </div>
          </div>
        </div>
      </section>

      {/* Calculator Section */}
      <section id="calculator" className="py-16">
        <CalculatorForm 
          onPredictionResult={setPredictionResult}
          onLoadingChange={setIsLoading}
          isLoading={isLoading}
        />
      </section>

      {/* Results Section */}
      {predictionResult && (
        <section className="py-16 bg-gray-50">
          <PredictionResults 
            result={predictionResult}
            onRefresh={() => window.location.reload()}
          />
        </section>
      )}

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20">
        <HowItWorks />
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-blue-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-6">Trusted by Millions</h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Since 2007, we've been the most accurate and trusted snow day prediction service in North America.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">5M+</div>
              <div className="text-blue-100 font-semibold">Annual Users</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">100M+</div>
              <div className="text-blue-100 font-semibold">Yearly Predictions</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">95%</div>
              <div className="text-blue-100 font-semibold">Accuracy Rate</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">17</div>
              <div className="text-blue-100 font-semibold">Years of Service</div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <ContactForm />
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <Snowflake className="text-blue-400 text-2xl" />
                <h3 className="text-xl font-bold">Snow Day Calculator</h3>
              </div>
              <p className="text-gray-300 mb-4">
                The most trusted snow day prediction service since 2007. Accurate, reliable, and used by millions of students, parents, and educators across North America.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => scrollToSection('calculator')}
                    className="text-gray-300 hover:text-blue-400 transition-colors"
                  >
                    Calculator
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('how-it-works')}
                    className="text-gray-300 hover:text-blue-400 transition-colors"
                  >
                    How It Works
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => scrollToSection('contact')}
                    className="text-gray-300 hover:text-blue-400 transition-colors"
                  >
                    Contact Us
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-600 mt-8 pt-8 text-center">
            <p className="text-gray-300">© 2024 Snow Day Calculator. All rights reserved. Created with ❄️ for students everywhere.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
