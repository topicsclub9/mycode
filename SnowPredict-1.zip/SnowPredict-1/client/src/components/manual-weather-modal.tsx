import { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ManualWeatherModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
}

export default function ManualWeatherModal({ open, onClose, onSubmit }: ManualWeatherModalProps) {
  const [weatherData, setWeatherData] = useState({
    snowfall: 0,
    temperature: 32,
    windSpeed: 0,
    stormStartTime: "evening" as const,
    freezingRain: false,
    iceStorm: false,
    blackIce: false
  });

  const handleSubmit = () => {
    onSubmit(weatherData);
    onClose();
  };

  const handleCancel = () => {
    // Reset form
    setWeatherData({
      snowfall: 0,
      temperature: 32,
      windSpeed: 0,
      stormStartTime: "evening",
      freezingRain: false,
      iceStorm: false,
      blackIce: false
    });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-screen overflow-y-auto">
        <DialogHeader className="pb-4 border-b">
          <DialogTitle className="text-2xl font-bold text-gray-800">
            Manual Weather Data Entry
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-semibold text-gray-800 mb-2 block">
                Expected Snowfall (inches)
              </Label>
              <Input
                type="number"
                min="0"
                max="24"
                step="0.1"
                placeholder="0-24"
                value={weatherData.snowfall}
                onChange={(e) => setWeatherData(prev => ({ ...prev, snowfall: Number(e.target.value) }))}
              />
            </div>
            
            <div>
              <Label className="text-sm font-semibold text-gray-800 mb-2 block">
                Temperature (°F)
              </Label>
              <Input
                type="number"
                min="-50"
                max="50"
                placeholder="-20 to 50"
                value={weatherData.temperature}
                onChange={(e) => setWeatherData(prev => ({ ...prev, temperature: Number(e.target.value) }))}
              />
            </div>
            
            <div>
              <Label className="text-sm font-semibold text-gray-800 mb-2 block">
                Wind Speed (mph)
              </Label>
              <Input
                type="number"
                min="0"
                max="60"
                placeholder="0-60"
                value={weatherData.windSpeed}
                onChange={(e) => setWeatherData(prev => ({ ...prev, windSpeed: Number(e.target.value) }))}
              />
            </div>
            
            <div>
              <Label className="text-sm font-semibold text-gray-800 mb-2 block">
                Storm Start Time
              </Label>
              <Select 
                value={weatherData.stormStartTime} 
                onValueChange={(value) => setWeatherData(prev => ({ ...prev, stormStartTime: value as any }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="evening">Evening (6 PM - 12 AM)</SelectItem>
                  <SelectItem value="late-night">Late Night (12 AM - 6 AM)</SelectItem>
                  <SelectItem value="early-morning">Early Morning (6 AM - 10 AM)</SelectItem>
                  <SelectItem value="daytime">Daytime (10 AM - 6 PM)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-semibold text-gray-800 mb-3 block">
              Ice Conditions
            </Label>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="freezing-rain"
                  checked={weatherData.freezingRain}
                  onCheckedChange={(checked) => setWeatherData(prev => ({ ...prev, freezingRain: !!checked }))}
                />
                <Label htmlFor="freezing-rain">Freezing Rain Expected</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="ice-storm"
                  checked={weatherData.iceStorm}
                  onCheckedChange={(checked) => setWeatherData(prev => ({ ...prev, iceStorm: !!checked }))}
                />
                <Label htmlFor="ice-storm">Ice Storm Warning</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="black-ice"
                  checked={weatherData.blackIce}
                  onCheckedChange={(checked) => setWeatherData(prev => ({ ...prev, blackIce: !!checked }))}
                />
                <Label htmlFor="black-ice">Black Ice Likely</Label>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-4 pt-4 border-t">
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} className="bg-blue-600 hover:bg-blue-700 text-white">
            Use This Data
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
