import { CloudSnow, Brain, History } from "lucide-react";

export default function HowItWorks() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold text-gray-800 mb-6">How Our Predictions Work</h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          We analyze multiple data sources and use machine learning to provide the most accurate snow day predictions available.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 mb-16">
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CloudSnow className="text-white text-2xl" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-4">Real-Time Weather Data</h3>
          <p className="text-gray-600">
            We pull live data from the National Weather Service, analyzing snowfall timing, intensity, temperature, and ice forecasts.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Brain className="text-white text-2xl" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-4">Machine Learning Algorithm</h3>
          <p className="text-gray-600">
            Our AI learns from millions of predictions and actual outcomes to continuously improve accuracy for each school district.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <History className="text-white text-2xl" />
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-4">Historical Patterns</h3>
          <p className="text-gray-600">
            We analyze each school's closure history, local road conditions, and regional decision-making patterns.
          </p>
        </div>
      </div>

      {/* Weather Images */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="relative rounded-xl overflow-hidden shadow-lg">
          <img 
            src="https://images.unsplash.com/photo-1547036967-23d11aacaee0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
            alt="Heavy snowstorm conditions" 
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
            <span className="text-white font-semibold text-lg">Storm Intensity Analysis</span>
          </div>
        </div>

        <div className="relative rounded-xl overflow-hidden shadow-lg">
          <img 
            src="https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
            alt="Snow-covered school building" 
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
            <span className="text-white font-semibold text-lg">School Infrastructure</span>
          </div>
        </div>

        <div className="relative rounded-xl overflow-hidden shadow-lg">
          <img 
            src="https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
            alt="Weather forecast data and icons" 
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
            <span className="text-white font-semibold text-lg">Forecast Integration</span>
          </div>
        </div>
      </div>
    </div>
  );
}
