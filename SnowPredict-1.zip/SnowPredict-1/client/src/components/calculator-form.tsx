import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { MapPin, School, Calendar, CloudDownload, Edit3, Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { predictionSchema, type PredictionInput, type PredictionResult } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ManualWeatherModal from "@/components/manual-weather-modal";
import LoadingSpinner from "@/components/ui/loading-spinner";

interface CalculatorFormProps {
  onPredictionResult: (result: PredictionResult) => void;
  onLoadingChange: (loading: boolean) => void;
  isLoading: boolean;
}

export default function CalculatorForm({ onPredictionResult, onLoadingChange, isLoading }: CalculatorFormProps) {
  const [showManualWeather, setShowManualWeather] = useState(false);
  const [useManualData, setUseManualData] = useState(false);
  const { toast } = useToast();

  const form = useForm<PredictionInput>({
    resolver: zodResolver(predictionSchema),
    defaultValues: {
      zipCode: "",
      schoolType: undefined,
      snowDaysUsed: 0,
      manualWeather: undefined
    }
  });

  const onSubmit = async (data: PredictionInput) => {
    try {
      onLoadingChange(true);
      
      const response = await apiRequest("POST", "/api/predict", data);
      const result = await response.json();
      
      onPredictionResult(result);
      
      // Scroll to results
      setTimeout(() => {
        const resultsElement = document.querySelector('[data-results-section]');
        if (resultsElement) {
          resultsElement.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
      
      toast({
        title: "Prediction Complete",
        description: `${result.percentage}% chance of snow day`,
      });
      
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to calculate prediction",
        variant: "destructive"
      });
    } finally {
      onLoadingChange(false);
    }
  };

  const handleManualWeatherData = (weatherData: any) => {
    form.setValue("manualWeather", weatherData);
    setUseManualData(true);
    setShowManualWeather(false);
    toast({
      title: "Manual Weather Data Applied",
      description: "Using your custom weather inputs for prediction"
    });
  };

  const handleAutomaticWeather = () => {
    form.setValue("manualWeather", undefined);
    setUseManualData(false);
    toast({
      title: "Automatic Weather Data Selected",
      description: "Will use real-time weather data from your ZIP code"
    });
  };

  return (
    <>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="winter-card">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-2xl">
            <CardTitle className="text-2xl mb-2">Snow Day Prediction Calculator</CardTitle>
            <p className="text-blue-100">Enter your information below to get your personalized snow day forecast</p>
          </CardHeader>

          <CardContent className="p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                
                {/* Location and School Type */}
                <div className="grid md:grid-cols-2 gap-8">
                  <FormField
                    control={form.control}
                    name="zipCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center text-gray-800 font-semibold mb-3">
                          <MapPin className="text-blue-600 mr-2 h-4 w-4" />
                          ZIP Code (US/Canada)
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter your ZIP code" 
                            className="text-lg py-3"
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          We'll use this to get local weather data and school patterns
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="schoolType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="flex items-center text-gray-800 font-semibold mb-3">
                          <School className="text-blue-600 mr-2 h-4 w-4" />
                          School Type
                        </FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="text-lg py-3">
                              <SelectValue placeholder="Select your school type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="public-urban">Public Urban</SelectItem>
                            <SelectItem value="public-rural">Public Rural</SelectItem>
                            <SelectItem value="private-prep">Private/Prep</SelectItem>
                            <SelectItem value="boarding">Boarding School</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Different schools have different closure policies
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Snow Days Used */}
                <FormField
                  control={form.control}
                  name="snowDaysUsed"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center text-gray-800 font-semibold mb-3">
                        <Calendar className="text-blue-600 mr-2 h-4 w-4" />
                        Snow Days Used This Year
                      </FormLabel>
                      <div className="flex items-center space-x-4">
                        <FormControl>
                          <Input 
                            type="number"
                            min="0"
                            max="20"
                            placeholder="0"
                            className="w-32 text-lg py-3 text-center"
                            {...field}
                            onChange={(e) => field.onChange(Number(e.target.value))}
                          />
                        </FormControl>
                        <span className="text-gray-600">out of typically 5-6 allowed</span>
                      </div>
                      <FormDescription>
                        Schools may be more reluctant to close if they've used many days
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Weather Data Options */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="text-lg font-semibold text-gray-800 mb-4">Weather Data Source</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <Button 
                      type="button"
                      className={`flex items-center justify-center space-x-3 p-4 h-auto ${
                        !useManualData 
                          ? "bg-blue-600 hover:bg-blue-700 text-white" 
                          : "bg-gray-200 hover:bg-gray-300 text-gray-800"
                      }`}
                      onClick={handleAutomaticWeather}
                    >
                      <CloudDownload className="h-5 w-5" />
                      <span className="font-semibold">Use Automatic Weather Data</span>
                    </Button>
                    <Button 
                      type="button"
                      variant="outline"
                      className={`flex items-center justify-center space-x-3 p-4 h-auto ${
                        useManualData 
                          ? "bg-blue-600 hover:bg-blue-700 text-white border-blue-600" 
                          : "bg-gray-200 hover:bg-gray-300 text-gray-800"
                      }`}
                      onClick={() => setShowManualWeather(true)}
                    >
                      <Edit3 className="h-5 w-5" />
                      <span className="font-semibold">Enter Weather Manually</span>
                    </Button>
                  </div>
                  {useManualData && (
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm text-blue-800">✓ Using manual weather data for prediction</p>
                    </div>
                  )}
                </div>

                {/* Submit Button */}
                <div className="text-center">
                  <Button 
                    type="submit" 
                    disabled={isLoading}
                    className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-12 py-4 text-xl font-bold rounded-lg shadow-lg transform hover:scale-105 transition-all"
                  >
                    {isLoading ? (
                      <>
                        <LoadingSpinner className="mr-3" />
                        Calculating...
                      </>
                    ) : (
                      <>
                        <Calculator className="mr-3 h-5 w-5" />
                        Calculate Snow Day Chance
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      <ManualWeatherModal
        open={showManualWeather}
        onClose={() => setShowManualWeather(false)}
        onSubmit={handleManualWeatherData}
      />
    </>
  );
}
