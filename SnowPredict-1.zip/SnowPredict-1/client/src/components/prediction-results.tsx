import { RefreshCw, Share, Bell, CheckCircle, AlertTriangle, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { type PredictionResult } from "@shared/schema";

interface PredictionResultsProps {
  result: PredictionResult;
  onRefresh: () => void;
}

export default function PredictionResults({ result, onRefresh }: PredictionResultsProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Very High":
        return "prediction-high";
      case "High":
        return "prediction-high";
      case "Moderate":
        return "prediction-moderate";
      default:
        return "prediction-low";
    }
  };

  const getFactorIcon = (factor: string) => {
    if (factor.includes("expected") || factor.includes("High") || factor.includes("Ice")) {
      return <CheckCircle className="text-green-500 mr-2 h-4 w-4 flex-shrink-0" />;
    }
    if (factor.includes("Above freezing") || factor.includes("reluctant")) {
      return <AlertTriangle className="text-orange-500 mr-2 h-4 w-4 flex-shrink-0" />;
    }
    return <Info className="text-blue-600 mr-2 h-4 w-4 flex-shrink-0" />;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8" data-results-section>
      <Card className="winter-card">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Your Snow Day Prediction</h3>
            <p className="text-gray-600">Based on current weather data and historical patterns for your area</p>
          </div>

          {/* Prediction Result */}
          <div className={`${getStatusColor(result.status)} rounded-xl p-8 text-center mb-8 text-white`}>
            <div className="text-6xl font-bold mb-4">{result.percentage}%</div>
            <div className="text-2xl font-semibold mb-2">{result.status} Chance</div>
            <div className="text-lg opacity-90">
              {result.percentage >= 70 ? "Strong likelihood of school closure" :
               result.percentage >= 40 ? "Moderate chance of closure" :
               "Low probability of closure"}
            </div>
          </div>

          {/* Prediction Factors */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gray-50 rounded-lg p-6">
              <h4 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm mr-2">❄</span>
                Weather Factors
              </h4>
              <ul className="space-y-2 text-gray-600">
                {result.weatherFactors.map((factor, index) => (
                  <li key={index} className="flex items-start">
                    {getFactorIcon(factor)}
                    <span className="text-sm">{factor}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gray-50 rounded-lg p-6">
              <h4 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm mr-2">🏫</span>
                School Factors
              </h4>
              <ul className="space-y-2 text-gray-600">
                {result.schoolFactors.map((factor, index) => (
                  <li key={index} className="flex items-start">
                    {getFactorIcon(factor)}
                    <span className="text-sm">{factor}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Reasoning */}
          {result.reasoning.length > 0 && (
            <div className="bg-blue-50 rounded-lg p-6 mb-8">
              <h4 className="text-lg font-semibold text-gray-800 mb-3">Key Reasoning</h4>
              <ul className="space-y-2">
                {result.reasoning.map((reason, index) => (
                  <li key={index} className="flex items-start text-gray-700">
                    <span className="w-2 h-2 rounded-full bg-blue-600 mt-2 mr-3 flex-shrink-0"></span>
                    <span className="text-sm">{reason}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Update Time */}
          <div className="text-center text-gray-500 mb-6">
            <span className="inline-flex items-center">
              🕐 Last updated: {result.lastUpdated}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap justify-center gap-4">
            <Button 
              onClick={onRefresh}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh Prediction
            </Button>
            <Button 
              variant="outline"
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'Snow Day Prediction',
                    text: `${result.percentage}% chance of snow day tomorrow!`,
                    url: window.location.href
                  });
                }
              }}
            >
              <Share className="mr-2 h-4 w-4" />
              Share Results
            </Button>
            <Button variant="outline">
              <Bell className="mr-2 h-4 w-4" />
              Get Text Alerts
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
