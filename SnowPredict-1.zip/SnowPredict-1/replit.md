# Snow Day Calculator

## Overview

A full-stack web application that predicts the likelihood of school closures due to snow and winter weather conditions. The application combines real-time weather data with machine learning algorithms to provide accurate snow day predictions for different school districts based on ZIP codes, school types, and historical patterns.

The system features a React frontend with a sophisticated weather prediction form, real-time weather data integration via OpenWeatherMap API, and a comprehensive prediction engine that considers multiple factors including snowfall amounts, temperature, wind speed, ice conditions, and school-specific closure patterns.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives for accessible, consistent interface elements
- **Styling**: Tailwind CSS with custom winter-themed color palette and responsive design
- **State Management**: TanStack React Query for server state management and API data caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ESM modules for modern JavaScript features
- **API Design**: RESTful endpoints for weather data fetching, predictions, and contact form submissions
- **Development**: Hot module replacement via Vite integration for rapid development cycles

### Data Storage Solutions
- **Primary Storage**: In-memory storage implementation for prediction history and contact submissions
- **Database Schema**: Drizzle ORM configured for PostgreSQL with migration support
- **Session Management**: PostgreSQL session store with connect-pg-simple for user session persistence

### Authentication and Authorization
- **Session-based**: Cookie-based session management without complex authentication flows
- **CORS**: Configured for cross-origin requests with credential support
- **Rate Limiting**: Built-in Express middleware for API endpoint protection

### Weather Data Integration
- **Provider**: OpenWeatherMap API for real-time weather data and forecasting
- **Geocoding**: ZIP code to coordinates conversion for accurate weather data retrieval
- **Processing**: 24-hour weather forecast analysis with snowfall, temperature, and wind speed calculations
- **Fallback**: Manual weather input option for scenarios where API data is unavailable

### Prediction Engine
- **Algorithm**: Multi-factor analysis considering weather conditions, school type, and snow days already used
- **School Types**: Support for public urban/rural, private prep, and boarding school closure patterns
- **Weather Factors**: Snowfall amount, temperature ranges, wind speed, storm timing, and ice conditions
- **Risk Assessment**: Percentage-based likelihood with categorical risk levels (Low, Moderate, High, Very High)

### Component Architecture
- **Design System**: Comprehensive UI component library with consistent theming and accessibility
- **Form Components**: Reusable form elements with validation and error handling
- **Modal System**: Overlay components for manual weather data entry and user interactions
- **Responsive Design**: Mobile-first approach with adaptive layouts for all screen sizes

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form for component architecture and form management
- **Build Tools**: Vite for development server and production builds, TypeScript for type safety
- **Styling**: Tailwind CSS for utility-first styling, PostCSS for CSS processing

### UI and Design Libraries
- **Component Library**: Radix UI primitives for accessible component foundations
- **Icons**: Lucide React for consistent iconography throughout the application
- **Animations**: CSS-based animations and transitions for smooth user interactions

### Data and API Management
- **HTTP Client**: Native Fetch API for weather data retrieval and backend communication
- **State Management**: TanStack React Query for server state caching and synchronization
- **Validation**: Zod for runtime type validation and schema definition

### Database and Storage
- **ORM**: Drizzle ORM for type-safe database interactions and schema management
- **Database Driver**: Neon Database serverless PostgreSQL connector for cloud database access
- **Session Storage**: connect-pg-simple for PostgreSQL-backed session management

### Development and Build Tools
- **Development**: ESBuild for fast bundling, TSX for TypeScript execution
- **Deployment**: Configured for production builds with static asset optimization
- **Environment**: Environment variable configuration for API keys and database connections

### Third-Party APIs
- **Weather Service**: OpenWeatherMap API for current conditions and forecasting data
- **Rate Limiting**: API request management to stay within service quotas
- **Error Handling**: Comprehensive error handling for API failures and network issues