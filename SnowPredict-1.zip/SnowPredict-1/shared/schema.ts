import { z } from "zod";

export const schoolTypes = [
  "public-urban",
  "public-rural", 
  "private-prep",
  "boarding"
] as const;

export const predictionSchema = z.object({
  zipCode: z.string().min(5, "ZIP code must be at least 5 characters").max(10, "ZIP code must be at most 10 characters"),
  schoolType: z.enum(schoolTypes),
  snowDaysUsed: z.number().min(0).max(20),
  manualWeather: z.object({
    snowfall: z.number().min(0).max(24),
    temperature: z.number().min(-50).max(50),
    windSpeed: z.number().min(0).max(100),
    stormStartTime: z.enum(["evening", "late-night", "early-morning", "daytime"]),
    freezingRain: z.boolean(),
    iceStorm: z.boolean(),
    blackIce: z.boolean()
  }).optional()
});

export const contactSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Valid email is required"),
  subject: z.enum(["accuracy", "bug", "feature", "general", "partnership"]),
  message: z.string().min(10, "Message must be at least 10 characters")
});

export type PredictionInput = z.infer<typeof predictionSchema>;
export type ContactInput = z.infer<typeof contactSchema>;

export interface WeatherData {
  temperature: number;
  snowfall: number;
  windSpeed: number;
  conditions: string;
  stormTiming: string;
  iceRisk: boolean;
}

export interface PredictionResult {
  percentage: number;
  status: "Low" | "Moderate" | "High" | "Very High";
  reasoning: string[];
  weatherFactors: string[];
  schoolFactors: string[];
  lastUpdated: string;
}
