So, you're experiencing a problem?

If you're not sure how to use the lightbox, or are experiencing a problem with it, please ask on [StackOverflow](http://stackoverflow.com/) - you will most definitely get a faster response time and it leaves this GitHub issues for actual bugs and not support questions.

If you really do think you have a bug, please:

- [ ] Provide a link to your site or a full example
- [ ] Provide screenshots where appropriate
- [ ] Browser name and version
