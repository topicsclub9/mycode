// Call the dataTables jQuery plugin
"use strict";
$(document).ready(function() {
  $('#dataTable').DataTable();
});
